<?php $__env->startSection('add-css'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('dselect/css/dselect.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bs-toast toast toast-placement-ex m-2 fade bg-primary position-fixed bottom-0 end-0 p-3 <?php echo e(session('success') ? 'show' : 'hide'); ?>"
        role="alert" aria-live="assertive" aria-atomic="true" data-delay="2000">
        <div class="toast-header">
            <i class="bx bx-bell me-2"></i>
            <div class="me-auto fw-semibold">Suksess</div>
            <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
        </div>
        <div class="toast-body"><?php echo e(session('success') ? session('success') : ''); ?></div>
    </div>

    <div class="container">
        <a href="/rekaman-tartib/create" class="btn btn-primary my-5">Tambah Data</a>

        <table id="example" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Guru </th>
                    <th>Tata Tertib</th>
                    <th>Siswa</th>
                    <th>Tahun Pelajaran</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rek; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($r->guru->nama); ?></td>
                        <td><?php echo e($r->tataTertib->tata_tertib); ?></td>
                        <td><?php echo e($r->siswa->nama); ?></td>
                        <td><?php echo e($r->tahun_pelajaran); ?></td>
                        <td><?php echo e($r->tanggal); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('add-script'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                scrollX: true,
            });
        });
    </script>

    <script src="<?php echo e(asset('dselect/js/dselect.min.js')); ?>"></script>
    <script>
        dselect(document.querySelector('#selectWalas'), {
            search: true
        })
        dselect(document.querySelector('#Kelas'), {
            search: true
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('siswa.main.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bayu\Project Web\sekolah-bk\resources\views/siswa/index/list.blade.php ENDPATH**/ ?>